$('#addPosition').click(function(){
	$('#modal-addPosition').modal('show');
});