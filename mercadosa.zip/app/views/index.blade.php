@extends('templates.maintemplate')

@section('contenido')
	@include('includes.dashboard.indexrole0')
@stop