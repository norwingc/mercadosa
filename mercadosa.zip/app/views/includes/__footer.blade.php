 <!-- Main Footer -->
<footer class="main-footer">
    <!-- To the right -->
    <!-- <div class="pull-right hidden-xs">Anything you want</div> -->
    <!-- Default to the left -->
    <strong>Doctor PC &copy; 2016 <a href="http://doctorpc.com.ni/" target="new">Doctor PC</a>.</strong> All rights reserved.
</footer>